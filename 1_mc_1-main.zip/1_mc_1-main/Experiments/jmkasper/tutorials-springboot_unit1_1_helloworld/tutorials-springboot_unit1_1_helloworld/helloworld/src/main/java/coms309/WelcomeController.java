package coms309;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
class WelcomeController {

    @GetMapping("/")
    public String welcome() {
        return "Hello and welcome to Financio!";
    }

    @GetMapping("/{name}")
    public String welcome(@PathVariable String name) {
        return "Hello " + name +", welcome to Financio: ";
    }
    
    @PostMapping("/")
    public String postTest(@RequestBody String test) {
    	return test;
    }
    
    public String 
}
