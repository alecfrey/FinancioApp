package onetomany;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import onetomany.Budget.BudgetRepository;
import onetomany.Expense.ExpenseRepository;
import onetomany.Users.*;







@SpringBootApplication
class Main {

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    // Create 3 users with their machines and phones
    @Bean
    CommandLineRunner initUser(UserRepository userRepository, ExpenseRepository expenseRepository, BudgetRepository phoneRepository) {
        return args -> {
            User user1 = new User("jmkasper", "HellowWorld", "1234 Hickory Park Rd.", "Ames", "Iowa", 50014, "Jeff", "F", "Kasper", "Male", "", "jmkasper@iastate.edu");
            userRepository.save(user1);
        };
    }

}