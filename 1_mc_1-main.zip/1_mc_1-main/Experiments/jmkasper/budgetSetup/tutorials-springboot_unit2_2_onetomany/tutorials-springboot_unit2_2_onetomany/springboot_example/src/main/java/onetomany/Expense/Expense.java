package onetomany.Expense;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import onetomany.Budget.Budget;

@Entity
public class Expense { 
	
	@Id
	@JoinColumn(name = "expenseId")
	@GeneratedValue(strategy = GenerationType.TABLE)
    private int id;
	
	private String name;
	private Date dateCreated;
	private Date dateModified;
	private Date dateRemoved;
	private int budgetedAmount;
    
    @OneToOne
    private Budget budget;

     // =============================== Constructors ================================== //
    
    public Expense(String name, int budgetedAmount) {
        this.name = name;
        this.budgetedAmount = budgetedAmount;
        this.dateCreated = new Date(System.currentTimeMillis());
    }
    
    public Expense() {}

    // =============================== Getters and Setters for each field ================================== //

	public int getExpenseId() {
		return id;
	}

	public void setExpenseId(int expenseId) {
		this.id = expenseId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}

	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}

	public Date getDateRemoved() {
		return dateRemoved;
	}

	public void setDateRemoved(Date dateRemoved) {
		this.dateRemoved = dateRemoved;
	}

	public int getBudgetedAmount() {
		return budgetedAmount;
	}

	public void setBudgetedAmount(int budgetedAmount) {
		this.budgetedAmount = budgetedAmount;
	}

	public Budget getBudget() {
		return budget;
	}

	public void setBudget(Budget budget) {
		this.budget = budget;
	}

}
