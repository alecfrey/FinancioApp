package onetomany.Budget;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import onetomany.Expense.Expense;
import onetomany.Users.User;

@Entity
public class Budget { 
	
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private int budgetId;
	
    @ManyToOne
    @JoinColumn(name = "userId")
    @JsonIgnore
    private User user;
    
    @OneToOne
    @JoinColumn(name = "expenseId")
    @JsonIgnore
    private Expense expense;

     // =============================== Constructors ================================== //
    
    public Budget(User user, Expense expense) {
        this.user = user;
        this.expense = expense;
    }
    
    public Budget() {}

    // =============================== Getters and Setters for each field ================================== //

	public User getUser() {
		return user;
	}


	public Expense getExpense() {
		return expense;
	}

}
