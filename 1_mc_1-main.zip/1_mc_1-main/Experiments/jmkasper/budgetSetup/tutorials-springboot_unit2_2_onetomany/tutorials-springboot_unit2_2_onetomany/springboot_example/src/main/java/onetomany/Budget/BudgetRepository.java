package onetomany.Budget;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BudgetRepository extends JpaRepository<Budget, Long> { // ToDo : Remake
//    Budget findById(int id);
}
