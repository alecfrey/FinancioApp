package onetomany.Budget;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import onetomany.Expense.Expense;
import onetomany.Expense.ExpenseRepository;
import onetomany.Users.User;
import onetomany.Users.UserRepository;

@RestController
public class BudgetController { // ToDo : Remake

    @Autowired
    BudgetRepository budgetRepository;
    @Autowired
    ExpenseRepository expenseRepository;
    @Autowired
    UserRepository userRepository;
    
    private String success = "{\"message\":\"success\"}";
    private String failure = "{\"message\":\"failure\"}";

    @GetMapping(path = "/budget")
    List<Budget> getAllbudgets(){
        return budgetRepository.findAll();
    }
    
    @PostMapping(path = "/budget/{expenseId}/{userId}")
	String createBudget(@PathVariable int expenseId, @PathVariable int userId) {
    	Expense expense = expenseRepository.findById(expenseId);
    	User user = userRepository.findById(userId);
    	if(expense == null || user == null)
    		return failure;
    	Budget budget = new Budget(user,expense);
    	user.addExpense(budget);
    	budgetRepository.save(budget);
    	return success;
    }

}
