package onetomany.Users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import onetomany.Budget.Budget;



/**
 * 
 * @author Jeffery Kasper
 * 
 */ 

@RestController
public class UserController { 

    @Autowired
    UserRepository userRepository;

    private String success = "{\"message\":\"success\"}";
    private String failure = "{\"message\":\"failure\"}";

    @GetMapping(path = "/user")
    List<User> getAllUsers(){
        return userRepository.findAll();
    }

    @GetMapping(path = "/user/{id}")
    User getUserById( @PathVariable int id){
        return userRepository.findById(id);
    }

    @PostMapping(path = "/user")
    String createUser(@RequestBody User user){
        if (user == null)
            return failure;
        userRepository.save(user);
        return success;
    }

    @PutMapping("/user/{id}")
    User updateUser(@PathVariable int id, @RequestBody User request){
        User user = userRepository.findById(id);
        if(user == null)
            return null;
        userRepository.save(request);
        return userRepository.findById(id);
    }   
    
    @GetMapping("user/{id}/budget")
    List<Budget> getUserBudget(@PathVariable int id){
    	User user = userRepository.findById(id);
    	if(user == null)
    		return null;
    	return user.getBudget();
    }
    
    @PostMapping("user/{id}/budget")
    String setUserBudget(@PathVariable int id, @RequestBody List<Budget> newBudget){
    	User user = userRepository.findById(id);
    	if(user == null)
    		return failure;
    	user.setBudget(newBudget);
    	return success;
    }
    
    @PutMapping("user/{id}/budget")
    String addToUserBudget(@PathVariable int id, @RequestBody List<Budget> toAdd){
    	User user = userRepository.findById(id);
    	if(user == null)
    		return failure;
    	for(int i=0; i<toAdd.size(); ++i) {
    		user.addExpense(toAdd.get(i));
    	}
    	return success;
    	
    }

}
