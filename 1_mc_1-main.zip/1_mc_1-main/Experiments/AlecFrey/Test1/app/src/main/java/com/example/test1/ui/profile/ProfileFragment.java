package com.example.test1.ui.profile;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.test1.R;
import com.example.test1.databinding.FragmentProfileBinding;

public class ProfileFragment extends Fragment {

    private ProfileViewModel profileViewModel;
    private FragmentProfileBinding binding;

    private MenuItem miEditProfile;
    private EditText etUsername;
    private EditText etGender;
    private EditText etAge;

    private Button btnEditProfilePicture;
    private ImageView imgProfilePicture;

    /**TEMP*/
    private Button btnEditProfile;

    private int PICK_IMAGE = 1;
    private boolean editProfileToggle = false;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        profileViewModel = new ViewModelProvider(this).get(ProfileViewModel.class);

        binding = FragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        btnEditProfilePicture = root.findViewById(R.id.btnEditProfilePicture);
        imgProfilePicture = root.findViewById(R.id.imgProfilePicture);

        btnEditProfilePicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               pickImageGallery();
            }
        });

        btnEditProfile = root.findViewById(R.id.btnEditProfile);
        btnEditProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                toggleEditText(etUsername, editProfileToggle);
                toggleEditText(etGender, editProfileToggle);
                toggleEditText(etAge, editProfileToggle);
                editProfileToggle = !editProfileToggle;
            }
        });

        miEditProfile = root.findViewById(R.id.miEditProfile);
        etUsername = root.findViewById(R.id.etProfileUsername);
        etGender = root.findViewById(R.id.etProfileSetGender);
        etAge = root.findViewById(R.id.etProfileSetAge);

        /**
        etUsername.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                etUsername.setText("Alec Frey");
                return true;
            }
        });
        */

        return root;
    }
    private void toggleEditText(EditText editText, Boolean toggle) {
        if (!toggle) {
            editText.setEnabled(false);
            editText.setInputType(InputType.TYPE_NULL);
            editText.setTextColor(Color.BLACK);
            editText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            editText.setFocusable(false);
        } else  {
            editText.setEnabled(true);
            editText.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            editText.setTextColor(Color.GRAY);
            editText.setTypeface(Typeface.DEFAULT,Typeface.BOLD_ITALIC);
            editText.setFocusableInTouchMode (true);
        }
        editText.setBackgroundColor(Color.TRANSPARENT);
    }

    private void pickImageGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            Uri uri = data.getData();
            imgProfilePicture.setImageURI(uri);
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // inflate menu
        //inflater.inflate(R.menu.top_bar_menu, menu);

        // hide menu item
        menu.findItem(R.id.miAddCategory).setVisible(false);
        menu.findItem(R.id.miLeaderboards).setVisible(false);
        menu.findItem(R.id.miAddFriend).setVisible(false);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.miEditProfile) {
            Toast.makeText(getActivity(), "Profile Fields Can Be Edited", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}