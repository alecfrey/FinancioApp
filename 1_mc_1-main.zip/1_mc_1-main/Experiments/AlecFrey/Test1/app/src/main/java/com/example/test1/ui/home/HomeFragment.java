package com.example.test1.ui.home;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.test1.MainActivity;
import com.example.test1.R;
import com.example.test1.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;

    private TextView tvTotalSpent;
    private TextView tvCategory1;
    private TextView tvCategory2;

    private EditText etCategory1Add;
    private EditText etCategory2Add;

    private Button btnAddFoodSpent;
    private Button btnAddSubscriptionSpent;

    private double totalSpent = 0;
    private double totalSpentCategory1 = 0;
    private double totalSpentCategory2 = 0;


    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        homeViewModel = new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        etCategory1Add = root.findViewById(R.id.etInputFoodCost);
        tvCategory1 = root.findViewById(R.id.tvTotalSpentEatingOut);
        tvTotalSpent = root.findViewById(R.id.tvTotalSpent);
        btnAddFoodSpent = root.findViewById(R.id.btnIncreaseFoodSpent);

        etCategory2Add = root.findViewById(R.id.etInputSubscriptionCost);
        tvCategory2 = root.findViewById(R.id.tvTotalSpentSubscriptions);
        btnAddSubscriptionSpent = root.findViewById(R.id.btnIncreaseSubscriptionSpent);

        btnAddFoodSpent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sNum = etCategory1Add.getText().toString();
                double num = Double.parseDouble(sNum);

                totalSpent += num;
                totalSpentCategory1 += num;

                tvCategory1.setText(String.format("$%,.2f", totalSpentCategory1));
                tvTotalSpent.setText(String.format("$%,.2f", totalSpent));
            }
        });

        btnAddSubscriptionSpent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sNum = etCategory2Add.getText().toString();
                double num = Double.parseDouble(sNum);

                totalSpent += num;
                totalSpentCategory2 += num;

                tvCategory2.setText(String.format("$%,.2f", totalSpentCategory2));
                tvTotalSpent.setText(String.format("$%,.2f", totalSpent));
            }
        });
        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // inflate menu
        //inflater.inflate(R.menu.top_bar_menu, menu);

        // hide menu item
        menu.findItem(R.id.miLeaderboards).setVisible(false);
        menu.findItem(R.id.miEditProfile).setVisible(false);
        menu.findItem(R.id.miAddFriend).setVisible(false);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // handle menu item clicks
        if (item.getItemId() == R.id.miLeaderboards) {
            Toast.makeText(getActivity(), "Leaderboards", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}