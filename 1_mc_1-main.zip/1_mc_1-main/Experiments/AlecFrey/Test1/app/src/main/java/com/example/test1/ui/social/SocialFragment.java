package com.example.test1.ui.social;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.test1.R;
import com.example.test1.databinding.FragmentSocialBinding;

public class SocialFragment extends Fragment {

    private SocialViewModel socialViewModel;
    private FragmentSocialBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        socialViewModel = new ViewModelProvider(this).get(SocialViewModel.class);

        binding = FragmentSocialBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        return root;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        // inflate menu
        //inflater.inflate(R.menu.top_bar_menu, menu);

        // hide menu item
        menu.findItem(R.id.miLeaderboards).setVisible(true);
        menu.findItem(R.id.miAddCategory).setVisible(false);
        menu.findItem(R.id.miEditProfile).setVisible(false);
        menu.findItem(R.id.miAddFriend).setVisible(true);

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        // handle menu item clicks
        if (item.getItemId() == R.id.miLeaderboards) {
            Toast.makeText(getActivity(), "Leaderboards", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}