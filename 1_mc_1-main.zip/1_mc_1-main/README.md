# 1_MC_1

Financio App - Personal Finance

## Team Members
Jeffery Kasper
Alec Frey
Parker Schmitz
