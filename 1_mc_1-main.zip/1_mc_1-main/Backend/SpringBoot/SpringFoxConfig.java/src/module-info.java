module SpringFoxConfig.java {
}